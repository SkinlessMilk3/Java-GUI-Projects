package sample;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.time.LocalDateTime;
import java.time.Month;

public class Main extends Application {

    protected enum Months{
        April (4, 30),
        May (5, 31),
        June (6, 30),
        July (7, 31),
        August (8, 31),
        September (9, 30);

        private final int month;
        private final int days;

        Months(int month, int days){
            this.month = month;
            this.days = days;
        }

        protected int getMonthVal(){
            return this.month;
        }

        protected int getDaysVal(){
            return this.days;
        }
    }

    @Override
    public void start(Stage primaryStage) throws Exception{

        GridPane root = new GridPane();
        primaryStage.setMaximized(true);
        primaryStage.setTitle("Cyberpunk 2077 Countdown");
        primaryStage.setScene(new Scene(root, 300, 275));
        primaryStage.show();

        Label timer = new Label();
        timer.setFont(new Font("TimesNewRoman", 30));
        Image img = new Image(getClass().getResourceAsStream("metro-en.jpg"));

        timer.setTextFill(Color.WHITE);
        root.setBackground(new Background(new BackgroundImage(img, BackgroundRepeat.REPEAT, BackgroundRepeat.REPEAT, BackgroundPosition.CENTER, BackgroundSize.DEFAULT)));
        /*
            Action when button is pressed.
         */
        /*btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                System.out.println("hi");
            }
        });*/

        root.setAlignment(Pos.CENTER);
        root.getChildren().add(timer);

        Countdown(timer);
    }


    public static void main(String[] args) {
        launch(args);
    }

    protected void Countdown(Label timer){

        Task t = new Task<Void>() {

            @Override
            protected Void call() throws Exception {

                while(true){
                    LocalDateTime time = LocalDateTime.now();
                    int seconds = Seconds(time);
                    int days = Days(time, Months.September, 17);
                    int hours = Hours(time);
                    int minutes = Minutes(time);

                    Platform.runLater(new Runnable(){
                        @Override public void run(){

                            timer.setText(Integer.toString(days) + ":" + Integer.toString(hours)+":"+ minutes+":"+seconds);
                        }
                    });
                    Thread.sleep(1000);

                }
            }
        };

        Thread th = new Thread(t);
        th.setDaemon(true);
        th.start();
    }

    protected int Days(LocalDateTime currTime, Months ending, int endDay){

        int distance = 0;

        for(Months month : Months.values()){
            if(ending.getMonthVal() == month.getMonthVal()){
                distance += endDay;
            }
            else if(month.getMonthVal() == currTime.getMonthValue()){
                distance += month.getDaysVal() - currTime.getDayOfMonth();
            }
            else{
                distance += month.getDaysVal();
            }
        }

        return distance-1;
    }

    protected int Hours(LocalDateTime currTime){//Months ending, int endDay){

        int remTime = 24 - currTime.getHour();
        return remTime;
    }

    protected int Minutes(LocalDateTime time){

        int remTime = 60 - time.getMinute();

        return remTime;
    }

    protected  int Seconds(LocalDateTime time){

        int remTime = 60 -  time.getSecond();

        return remTime;
    }
}
